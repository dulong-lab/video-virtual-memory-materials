
This is an example how to find the base of ntoskrnl.exe.

Use KmdManager to register/unregister and start/stop it.
Watch its debug output with the DbgView (www.sysinternals.com) or use SoftICE.

Tested on: Windows 2000, XP & Server 2003
______________________
Four-F, four-f@mail.ru
