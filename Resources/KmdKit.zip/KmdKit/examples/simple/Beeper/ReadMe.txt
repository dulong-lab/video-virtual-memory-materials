How to beep with system speaker.

Tested on: Windows NT4.0+sp6, 2000, XP & Server 2003

______________________
Four-F, four-f@mail.ru