
This is an example how to notify the user mode about some sort of �event� has happened.

Tested under: Windows 2000, XP and Server 2003.

______________________
Four-F, four-f@mail.ru