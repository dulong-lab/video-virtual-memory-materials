
This is an example how to put code in different PE-sections.

______________________
Four-F, four-f@mail.ru