Libs for Windows 2000, including Professional, Server, Advanced Server, Datacenter Server, and Windows 2000 Service Pack 1.
Free build.

from 2kddknly.exe
