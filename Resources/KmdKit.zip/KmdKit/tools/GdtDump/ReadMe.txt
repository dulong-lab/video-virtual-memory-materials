
Global Descriptor Table Dumper

Let you browse GDT content.

______________________
Four-F, four-f@mail.ru
