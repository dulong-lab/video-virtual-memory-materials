
protogen - Prototype Generator.

Let you create include files with function prototypes.
Currently MASM compatible only.

It may be buggy! The source code is not easiest one.
Sometimes I spend some time to understand what is going on ;-)
So, having found some bug, please, mail me.

______________________
Four-F, four-f@mail.ru