protoize by f0dder - f0dder@yahoo.com

Converts a .lib file to .inc file

Usage: protoize [import library file]
