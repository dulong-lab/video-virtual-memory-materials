
Symbolic Links Viewer

MS-DOS device names are global and visible to all processes.
This tool lets you obtain a list of all MS-DOS devices known to the system.

______________________
Four-F, four-f@mail.ru